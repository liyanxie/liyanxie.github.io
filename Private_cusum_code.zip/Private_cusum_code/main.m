% The main demo code 

%% Laplace distribution change detection
clear all; close all; clc; 

times=100; %number of times to do the experiment
b = 1; %variance = 2b^2

% Parameters
mu = 0.2; % the post-change mean
nuo=linspace(0.2,5.5,10); %thresholds for exact cusum

epsilon = 0.2; % the DP parameter (can change to any other positive values such as 0.4,0.6,1,...)
nup=linspace(2,30,8);
[arlo, eddo, arlp, eddp, running_time] = dp_cusum_lap(mu, b, times, nuo, nup, epsilon);
disp(running_time);
legend_list = ["Exact CUSUM"];
legend_list = [legend_list, ['DP CUSUM, $\epsilon=$', num2str(epsilon)]];

figure;
semilogx(arlo,eddo,'k-o');
hold on 
semilogx(arlp,eddp,'--o');
legend(legend_list,'Interpreter','latex','Location','NorthWest');
xlabel('Average Run Length');
ylabel('Expected Detection Delay');

%% Normal distribution change detection

times=100; %number of times to do the experiment

% Parameters
mu = 0.1; %post-change mean
sigma = 1; %standard deviation
nuo=linspace(0.2,4.5,8); %thresholds for exact cusum

delta = 0.1; %DP parameter
Delta = 2*abs(mu)/sigma*norminv(1-delta/4) + mu^2/sigma^2; %A_delta

epsilon=0.5; %DP parameter
nup=linspace(1,14,8); %thresholds for dp cusum
[arlo, eddo, arlp, eddp, running_time] = dp_cusum_normal(mu, sigma, delta, times, nuo, nup, epsilon);
disp(running_time);
legend_list = ["Exact CUSUM"];
legend_list = [legend_list, ['DP CUSUM, $\epsilon=$', num2str(epsilon)]];

figure;
semilogx(arlo,eddo,'k-o');
hold on 
semilogx(arlp,eddp,'--o');
legend(legend_list,'Interpreter','latex','Location','NorthWest');
xlabel('Average Run Length');
ylabel('Expected Detection Delay');
xlim([10 1e4]);


