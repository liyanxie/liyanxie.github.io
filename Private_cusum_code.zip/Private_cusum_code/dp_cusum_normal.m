% dp_cusum_normal runs the DP-CUSUM procedure for normal distributions
% Pre-change distribution: N(0,sigma^2); post-change: N(mu, sigma^2);

%% Input parameters: 
% epsilon, delta are DP parameters;
% nuo are the detection threshold for exact (non-private) cusum (baseline);
% nup are the detection threshold for DP-CUSUM (our method);
% times is the total number of trials 

%% Outputs: 
%  arlo is the Average Run length of exact (non-private) cusum (baseline);
%  eddo is the average detection delay of exact (non-private) cusum (baseline);
%  arlp is the Average Run length of DP-CUSUM (our method);
%  eddp is the average detection delay of DP-CUSUM (our method);
%  running_time is the total running time of the experiment (in seconds)

function [arlo, eddo, arlp, eddp, running_time] = dp_cusum_normal(mu, sigma, delta, times, nuo, nup, epsilon)


Delta = 2*abs(mu)/sigma*norminv(1-delta/4) + mu^2/sigma^2; %A_delta


arlo=zeros(length(nuo),1); %exact (non-private) cusum
eddo=zeros(length(nuo),1);

arlp=zeros(length(nup),1); %private cusum
eddp=zeros(length(nup),1);


tic
for jjj=1:times

    nu_private = nup + laprnd(1,1, 0,2*Delta/epsilon);

    % track the progress
    if mod(jjj,100)==0
        elapsedTime = toc;
        fprintf('Time %f: Trial # %d out of %d.\n',elapsedTime,jjj,times);
    end

    Soinf=0;  %exact (non-private) cusum
    So0=0;

    Spinf=0; %private cusum
    Sp0=0;

    
    flago = zeros(2,length(nuo));   %flag is set when a stopping occurs         
    flagp=zeros(2,length(nup));   %flag is set when a stopping occurs

    t=0; %time counter 

    while min(min([flago,flagp]))==0
        t=t+1;

        xinf=sigma*randn(1,1); %pre-change sample
        x0=xinf+mu; %post-change sample

        %exact cusum
        if min(min(flago))==0

            Soinf=max(Soinf,0)+ (2*mu*xinf - mu^2)/(2*sigma^2);
            So0=max(So0,0)+(2*mu*x0 - mu^2)/(2*sigma^2);

            for iii=1:length(nuo)
                if flago(1,iii)==0
                    if Soinf >= nuo(iii)
                        arlo(iii)=arlo(iii)+t;
                        flago(1,iii)=1;
                    end
                end

                if flago(2,iii)==0
                    if So0 >= nuo(iii)
                        eddo(iii)=eddo(iii)+t;
                        flago(2,iii)=1;
                    end
                end
            end 
        end

        %dp cusum

        if min(min(flagp))==0

            Spinf=max(Spinf,0)+ (2*mu*xinf - mu^2)/(2*sigma^2);
            Sp0=max(Sp0,0)+(2*mu*x0 - mu^2)/(2*sigma^2);
            
            lap_noise = laprnd(1,1,0,2*Delta/epsilon);

            for iii=1:length(nup)
                if flagp(1,iii)==0
                    if Spinf + lap_noise >= nu_private(iii)
                        arlp(iii)=arlp(iii)+t;
                        flagp(1,iii)=1;
                    end
                end

                if flagp(2,iii)==0
                    if Sp0 + lap_noise >= nu_private(iii)
                        eddp(iii)=eddp(iii)+t;
                        flagp(2,iii)=1;
                    end
                end
            end
        end
    end


end
toc
    


arlo=arlo/times;
eddo=eddo/times;

arlp=arlp/times;
eddp=eddp/times;

running_time = toc;

end






