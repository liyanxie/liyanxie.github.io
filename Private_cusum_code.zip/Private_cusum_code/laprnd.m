function X = laprnd(m, n, mu, b)
%LAPRND Generate i.i.d. Laplace(mu, b) random variables of size m x n
%
%   X = laprnd(m, n, mu, b) returns an m-by-n matrix of Laplace random variables
%   with location parameter mu and scale parameter b.

    % Generate uniform random numbers in (-0.5, 0.5)
    U = rand(m, n) - 0.5;

    % Apply inverse CDF of Laplace distribution
    X = mu - b * sign(U) .* log(1 - 2 * abs(U));
end